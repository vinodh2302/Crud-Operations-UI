import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ProdserviceService } from 'src/services/prodservice.service';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    FormsModule , 
    BrowserModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [ProdserviceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
