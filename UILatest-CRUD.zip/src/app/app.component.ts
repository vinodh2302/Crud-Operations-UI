import { Component } from '@angular/core';
import { Product } from 'src/Model/Product';
import { ProdserviceService } from 'src/services/prodservice.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'product';
  onDataLoad: boolean = false;
  isInsertProduct: boolean = false;
  prodName: string | undefined;
  prodDesc: string | undefined;
  prodCategory: string | undefined;
  prodPrice: string = '';
  updateProdClicked: boolean = false;
  getProdName: string ='';
  deleteNameGet: string = '';
  getProdDescription: string ='';
  getProdCategory: string ='';
  getProdPrice : string ='';
  prodIdGet: number =0;
  prodNameGet: string ='';
  productsCount: number=0;
    products: any[] | undefined;
  _prod: ProdserviceService | undefined;
  constructor(private prod: ProdserviceService){
    this._prod = prod;
  }
  ngOnInit(){
  }

  loadData(){
    this.onDataLoad = false;
    this._prod?.getProducts().subscribe((data) =>{
      this.products = data;
      this.onDataLoad = true;
    });
  }

  insertProduct(){
    this.isInsertProduct = true;
  }

  getDataById(){
    this._prod?.getProductsById(this.prodIdGet).subscribe((data) =>{
      if(data){
        this.getProdName = data.name;
        this.getProdDescription = data.description;
        this.getProdPrice= data.price;
        this.getProdCategory = data.category;
      }
     });
  }

  getDataByName(){
    this.onDataLoad= false;
    this._prod?.getProductsByName(this.prodNameGet).subscribe((data) =>{
      if(data){
        this.products = data;
        this.onDataLoad= true;
      }
     });
  }

  saveclick(){
    let p: Product ;
    p = new Product();
    p.price = this.prodPrice;
    p.category = this.prodCategory;
    p.description = this.prodDesc;
    p.name = this.prodName
  

    if(this.updateProdClicked){
      this._prod?.updateProduct(p).subscribe((data) =>{
        if(data == null){
          alert('Update Successful')
        }
       });
    }else{
      this._prod?.addProduct(p).subscribe((data) =>{
        if(data == true){
         alert('Save Successful')
        }
       });
    }

  }

  getProductsCount(){
    this._prod?.getProductsCount().subscribe((data) =>{
      if(data){
       this.productsCount = data;
      }
     });
  }

  updateProduct(){
    this.isInsertProduct = true;
   this.updateProdClicked = true;
 }

 deleteProduct(){
  this._prod?.deleteProduct(this.deleteNameGet).subscribe((data) =>{
    if(data == null){
     alert('Delete Success')
    }
   });
 }

 deleteAll(){
  this._prod?.deleteAll().subscribe((data) =>{
    if(data == null){
     alert('Delete all Success')
    }
   });
 }

 sortProduct(){
  this._prod?.sortProduct().subscribe((data) =>{
    if(data){
     this.onDataLoad = true;
     this.products = data;
    }
   });
 }
}
