export class Product{
    name: string | undefined;
    description: string | undefined;
    category: string | undefined;
    price: string | undefined;
}