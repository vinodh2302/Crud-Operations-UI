
import { Injectable } from '@angular/core';
 
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { map, catchError} from 'rxjs/operators';
import { Product } from 'src/Model/Product';

@Injectable({
  providedIn: 'root'
})
export class ProdserviceService {
  baseURL: string | undefined;
  ext: string | undefined;
  constructor(private http: HttpClient) { }

  getProducts(): Observable<any> {
    this.baseURL = "https://localhost:7231/";
    this.ext = "Product/api/products";
    return this.http.get(this.baseURL + this.ext);
  }

  getProductsById(id: number): Observable<any> {
    this.baseURL = `https://localhost:7231/`;
    this.ext = `Product/api/products/${id}`;
    return this.http.get(this.baseURL + this.ext);
  }

  getProductsByName(name: string): Observable<any> {
    this.baseURL = `https://localhost:7231/`;
    this.ext = `Product/api/products/name/${name}`;
    return this.http.get(this.baseURL + this.ext);
  }

  addProduct(p: Product): Observable<boolean> {
    this.baseURL = "https://localhost:7231/";
    this.ext = "Product/api/product/post";
    return this.http.post<boolean>(this.baseURL + this.ext, p);
  }

  getProductsCount(): Observable<number> {
    this.baseURL = "https://localhost:7231/";
    this.ext = "Product/api/products/count";
    return this.http.get<number>(this.baseURL + this.ext);
  }

  updateProduct(p: Product): Observable<number> {
    this.baseURL = "https://localhost:7231/";
    this.ext = "Product/api/product/update";
    return this.http.post<number>(this.baseURL + this.ext, p);
  }

  deleteProduct(p: string): Observable<boolean> {
    this.baseURL = `https://localhost:7231/`;
    this.ext = `Product/api/product/delete/${p}`;
    return this.http.delete<boolean>(this.baseURL + this.ext);
  }

  deleteAll(): Observable<boolean> {
    this.baseURL = `https://localhost:7231/`;
    this.ext = `Product/api/product/deleteall`;
    return this.http.delete<boolean>(this.baseURL + this.ext);
  }

  
  sortProduct(): Observable<any> {
    this.baseURL = `https://localhost:7231/`;
    this.ext = `Product/api/product/sortbyname`;
    return this.http.get<boolean>(this.baseURL + this.ext);
  }
}
